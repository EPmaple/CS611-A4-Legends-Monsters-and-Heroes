/*
 * HeroType.java
 * Tony Cen Cen
 * 3/30/2024
 * 
 * Enum used to represent the different possible types of heroes
 */

public enum HeroType {
  WARRIOR,
  SORCERER,
  PALADIN;
}
