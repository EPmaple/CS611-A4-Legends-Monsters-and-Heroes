/*
 * MonsterType.java
 * Tony Cen Cen
 * 3/30/2024
 * 
 * Enum used to represent the different possible types of monsters
 */

public enum MonsterType {
  DRAGON,
  EXOSKELETON,
  SPIRIT;
}
